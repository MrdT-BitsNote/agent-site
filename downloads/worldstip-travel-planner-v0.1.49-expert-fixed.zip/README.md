# WorldsTip 旅行规划大师 · 专家包（v0.1.49）

> 根标志：`.codebuddy-plugin/plugin.json`；内嵌技能位于包内 skills 子目录，含完整 `SKILL.md`。

## 本次修复（对应 2026-11-05 14:25 质检驳回）

- 驳回项：资产包缺少必需资源 1 项（内嵌技能目录，由角色文件引用）
  （由 `agents/worldstip-travel-planner.md` 引用），结论「内置文件缺失」。
- 根因：技能包内的角色文件硬编码了专家包语境路径，而技能包里没有 `skills/` 目录。
- 修复：① 角色文件里的悬空路径改为结构无关表述；
  ② 专家包内嵌技能真实落盘（包内 skills 子目录），并含完整 `SKILL.md`；
  ③ `plugin.json` 的 `skills` 字段指向该目录，路径可解析。
- 版本三处一致：plugin.json `0.1.49` / 本 README `v0.1.49` / agent 标题行 `v0.1.49`。

## 上传

把本目录打成的 zip 上传到「专家 / 资产包」入口。若上传的是「技能」入口，
改用同批产出的 `worldstip-travel-planner-v0.1.49-skill-fixed.zip`（根 `SKILL.md`）。

不承诺过审；平台安全审核结论以平台通知为准。
