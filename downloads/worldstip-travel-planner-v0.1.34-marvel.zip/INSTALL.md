**本包内容**：`SKILL.md`（技能定义）+ `references/`（30+ 份数据参考）+ `scripts/`（数十个纯标准库 Python 脚本）+ `examples/`（范本）+ `agents/worldstip-travel-planner.md`（智能体提示词）。

**版本**：v0.1.34　**大小**：见下载卡　**许可**：MIT
## Marvel 安装方式

若 Marvel 支持「文件夹 / zip 技能导入」：直接导入本包根目录（含 `SKILL.md`）。

若仅支持提示词挂载：
1. 把本包 `SKILL.md` 的**正文**作为「系统提示词」粘贴到你的 Marvel 智能体。
2. 把 `references/` 作为「知识库」上传，并开启联网用于易变信息核验。
3. 开场白用 `agents/worldstip-travel-planner.md` 里的初始化提示。

> 如 Marvel 有专用技能 manifest 规范，可把它套在 `SKILL.md` 的 YAML 前置之外，再导入。
