# 扩展数据包：moto-places（景点级地点库 v0.1.41）

**这不是独立技能，是主技能 `worldstip-travel-planner` 的可选数据扩展。** 不装也能用，装了才有景点级候选。

## 装了有什么用

| | 未安装（默认） | 安装后 |
|---|---|---|
| 建议粒度 | 城市级（393 城，来自 `destinations.json`） | **景点级**（2514 个地点，带坐标 + 实景简介） |
| 检索方式 | — | `scripts/places_query.py` 按省/类型/关键词检索 |

## 安装方式

解压本包，把里面的 `references/` 与 `scripts/` 两个目录**覆盖到技能根目录**（与 `SKILL.md` 同级）：

```
<技能目录>/
  SKILL.md
  references/moto_places.json     ← 本包提供
  scripts/places_query.py         ← 本包提供
```

- **WorkBuddy / 本地技能**：覆盖到 `~/.workbuddy/skills/worldstip-travel-planner/`
- **千问 / Coze / 百度 / Marvel**：这些平台只认单个技能包，请在上传主包前把本包内容合并进去，或走「知识库」方式挂载 `moto_places.json`

## 用法（必须先 cd 到技能根目录）

```bash
python scripts/places_query.py --province 湖南 --limit 8
python scripts/places_query.py --kw 古镇 --limit 5
python scripts/places_query.py --list-provinces
```

退出码：`0` 有结果 / `1` 无匹配 / **`2` 扩展数据未安装**（主技能据此降级为城市级建议并挂灰灯）。

## 数据纪律

- **禁止把 `moto_places.json` 全文读入上下文**（约 40 万 token）。必须经 `places_query.py` 过滤后取结果。
- 默认排除质量问题条目（`fl` 非空：`text_mismatch` 名称与文案疑似不符 / `admin_coarse` 行政区粒度不足 / `type_unknown` 类别未识别），需 `--include-suspect` 显式放行。
- 数据版本与来源见文件内 `_meta`。
