# 旅行规划师（WorldsTip Travel Planner）· 专家包

国内 + 出境双模式旅行规划专家。在有限预算 / 天数 / 体力下替用户砍掉一半、排对顺序、并保证这趟不翻车，产出 A5 紧凑卡册风格（米白底+深墨绿主色+14px紧凑+零图+字段密集）、可直接照着走的 HTML/PDF 行程小册子。

- **插件名（id）**：`worldstip-travel-planner`
- **展示名**：旅行规划师
- **版本**：0.1.16
- **分类**：travel

## 包含的技能

| 技能 | 说明 |
|---|---|
| `skills/worldstip-travel-planner/` | 主技能：五大能力支柱 + 可信度内核（详见其 `SKILL.md`） |

## 五大能力支柱

1. **国内全交通族系**——公共交通（飞机/高铁/火车/客车/轮船）、自驾、骑行、徒步、极限运动、自然美景、演唱会锚点旅程。
2. **摩旅五项门禁自检**——准驾证件 / 头盔 / 逐省高速准入 / 逐城禁摩 / 续航加油半径；里程高德实算优先，估值标「（估）」，路点 place/text 校验防虚构，单日 >150km 评估拆 2 天。
3. **房车 / 自驾后勤自检**——按用户声明车型给限高、驾照牌照（蓝牌 C1·黄牌 B-A·拖挂 C6）、补给半径、黑水灰水合规处理、营地与路线优化、应急；终点停靠证据优先（只收官方正规设施、有设施≠能过夜、免费野营点不入库）。五项灯位只把违法上路判红灯，绝不推荐车型。
4. **出境可行性门禁卡**——护照 / 签证 / 疫苗 / 保险四灯（红灯先拦再谈行程）+ 准入 / 货币时差 / 合规文化禁忌 / 领事与安全 12308 四维约束。
5. **散心模式**——心情不好 / 只想放空时，跳过交通规划、行李清单、安全提醒、应急预案等"任务感"章节，只保留路线总览、季节气候、美景拍摄、住宿、预算速查、出发前多知道一点——轻量、治愈、不压迫。

## 可信度内核

事实分 `stable / volatile / unknown` 三档：易变信息强制联网核验并打日期戳、未核验挂降级角标、查不到即灰灯待查，**绝不编造**。数据以公开来源为准；如宿主提供知乎 / 小红书 / 抖音等 MCP，则调用其做交叉核验（技能自身不爬取、不批量抓取、不保存原文）。

## 目录结构

```
travel-planner-expert/
├── .qoder-plugin/
│   └── plugin.json          # 插件元数据（name/version/skills/interface）
├── skills/
│   └── worldstip-travel-planner/
│       ├── SKILL.md         # 技能定义
│       ├── references/      # 数据（JSON 参考库）
│       ├── scripts/         # 零第三方依赖的 Python 脚本 + 回归测试
│       ├── assets/  examples/
│       └── README.md  LICENSE  排版规范.md
├── assets/
│   └── logo.svg             # 插件图标
└── README.md
```

## 运行环境

- 主技能脚本为 **Python 3 标准库**，零第三方依赖。
- 联网核验为可选增强：无 Key 或调用失败自动回落估算并标注「估算 ⓘ」，不影响主流程。

## 版本纪律

对外发布版本号 = 本地开发包版本号 = **0.1.16**。任何一端改动后，**本地 / 千问 / 扣子 / 乐享 / Qoder 五端**必须同步到同一版本号，杜绝版本错位。

各端包格式不同（打包时用错格式会不被识别）：

| 端 | 首层结构 | 产物 |
|---|---|---|
| 千问 | `worldstip-travel-planner/` 目录包裹 | `worldstip-travel-planner-v0.1.16.zip` |
| 扣子 | 首层直接是 `SKILL.md` | `worldstip-travel-planner-v0.1.16-coze.zip` / `.skill` |
| Qoder | `.qoder-plugin/plugin.json` + `skills/` | `worldstip-travel-planner-expert-v0.1.16-qoder.zip` |
| WorkBuddy | `.codebuddy-plugin/plugin.json` + `agents/*.md` | `worldstip-travel-planner-expert-v0.1.16-workbuddy.zip` |

**重建纪律**：改动 `scripts/render_compact.py` 的 `HTML_TPL` 后，必须重建 `examples/` 下 8 份样例（4 主 + 4 `-light`），否则样例会停留在旧版式。
