# WorldsTip旅行指南小册子（worldstip-travel-planner）

在有限预算、天数和体力下，替你砍掉一半、排对顺序、保证不翻车——交付一份 A5 紧凑卡册风格的 HTML/PDF 行程小册子（米白底 + 深墨绿 + 14px 紧凑 + 字段密集 + 零图 + 零大留白）。

## 类型

Agent 型（单个 AI 专家）　|　版本 **v0.1.16**（与本地技能包 / 千问平台对外号一致）　|　作者 MrdT　|　https://worldstip.com

## 功能（四大支柱 + 散心模式）

1. **国内全交通族系**：公共交通（飞机/高铁/火车/客车/轮船）、自驾、骑行、徒步、极限运动、自然美景、演唱会锚点；未指定方式时出 6 方式比选表。
2. **摩旅五项门禁自检**：准驾车型证件 / 头盔 / 逐省高速准入（31 省）/ 逐城禁摩（45 城）/ 续航加油半径；含绿荫优先选线、加油决策点动作序列、出行前待核实清单、UGC 数据增强。
3. **房车 / 自驾后勤自检**：限高、驾照牌照（C1 蓝牌 / B·A 黄牌 / C6 拖挂）、补给半径、黑水灰水合规、营地与路线；终点停靠证据优先，不推荐车型。
4. **出境可行性门禁卡**：护照 / 签证 / 疫苗 / 保险四灯 + 4 维约束（准入、货币时差、文化禁忌、领事与 12308）。
5. **散心模式**：只给目的地报告，不讲交通，治愈系推荐。

贯穿全程的**可信度内核** `stable / volatile / unknown`：易变信息强制联网核验并打日期戳，查不到即挂灰灯待查，绝不编造。

## 包内结构

```
worldstip-travel-planner/
├── .codebuddy-plugin/plugin.json      # 专家元数据（WorkBuddy 规范）
├── agents/worldstip-travel-planner.md # 主 Agent 定义
├── avatars/expert.png                 # 512×512 头像
├── skills/worldstip-travel-planner/   # 技能包 v0.1.16（89 文件，无 __pycache__）
│   ├── SKILL.md  README.md  报告生成规范.md  排版规范.md
│   ├── scripts/    32 个纯标准库 Python 脚本（无第三方依赖）
│   ├── references/ 32 份数据（高速准入、禁摩名单、目的地、车站码、签证疫苗…）
│   └── examples/   8 份样例小册子
└── README.md
```

## 使用示例

- 周五晚出发周日下午回，从岳阳出发想爬山看日出，预算 800，出紧凑小册子。
- 摩托车从成都骑到康定：查准驾、头盔、四川高速准入、沿途禁摩和加油半径。
- 出境去日本，先判护照/签证/疫苗/保险四灯，再排 7 天行程。
- 最近心情不好，想出去走 3 天，不知道去哪（散心模式）。

## 头像

`avatars/expert.png`，512×512、422KB，已自动生成。如需替换为自定义头像：PNG/JPG、512×512、≤500KB。

## 安装

本包已位于专家目录：

```
C:\Users\Administrator.DESKTOP-HV32D5I\.workbuddy\plugins\marketplaces\my-experts\plugins\worldstip-travel-planner\
```

注册后（写入 marketplace.json）才会在 WorkBuddy 专家中心可见：

```bash
python scripts/register_expert.py "C:/Users/Administrator.DESKTOP-HV32D5I/.workbuddy/plugins/marketplaces/my-experts/plugins/worldstip-travel-planner"
```

校验：

```bash
python scripts/validate_expert.py "C:/Users/Administrator.DESKTOP-HV32D5I/.workbuddy/plugins/marketplaces/my-experts/plugins/worldstip-travel-planner"
```

## 版本同步纪律

技能本体改动后，需同步三端 + 本专家包：本地 `~/.workbuddy/skills/worldstip-travel-planner/`、千问平台 `@user_gc9bq/worldstip-travel-planner`、乐享/Coze 资产库、以及本包 `skills/` 副本与 `plugin.json.version`。

> 注意：`G:\WorldsTipAgent\worldstip-travel-planner-expert-v0.1.15.zip` 是 **Qoder 格式**（`.qoder-plugin`），且版本落后于本包（0.1.15 < 0.1.16），不要用它覆盖本包或上传千问。
